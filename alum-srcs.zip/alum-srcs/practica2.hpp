// *********************************************************************
// **
// ** Informática Gráfica, curso 2018-19
// ** Montserrat Rodríguez Zamorano
// ** Práctica 2  (declaraciones públicas)
// **
// *********************************************************************

#ifndef IG_PRACTICA2_HPP
#define IG_PRACTICA2_HPP

void P2_Inicializar(  ) ;
bool P2_FGE_PulsarTeclaCaracter(  unsigned char tecla ) ;
void P2_DibujarObjetos( ContextoVis & cv ) ;

#endif
