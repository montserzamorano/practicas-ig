// *********************************************************************
// **
// ** Informática Gráfica, curso 2018-19
// ** Montserrat Rodríguez Zamorano
// ** Práctica 3  (declaraciones públicas)
// **
// *********************************************************************

#ifndef IG_PRACTICA3_HPP
#define IG_PRACTICA3_HPP

void P3_Inicializar(  ) ;
bool P3_FGE_PulsarTeclaCaracter(  unsigned char tecla ) ;
void P3_DibujarObjetos( ContextoVis & cv ) ;
bool P3_FGE_Desocupado();

#endif
